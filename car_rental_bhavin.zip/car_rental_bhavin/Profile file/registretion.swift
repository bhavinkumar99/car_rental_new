//
//  registretion.swift
//  car_rental_bhavin
//
//  Created by MAC2 on 04/03/19.
//  Copyright © 2019 MAC2. All rights reserved.
//

import UIKit
import Firebase
class registretion: UIViewController {
 @IBOutlet weak var Fname: UITextField!
   @IBOutlet weak var Lname: UITextField!
   @IBOutlet weak var Email: UITextField!
   @IBOutlet weak var Password: UITextField!
   @IBOutlet weak var Mobile: UITextField!
    
    var ref = DatabaseReference.init()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    self.ref = Database.database().reference()
        
    }
    
    @IBAction func butregistretion(_ sender: UIButton) {
        
        let dic = ["Fname":Fname.text,"Lname":Lname.text,"Email":Email.text,"password":Password.text,"Mobile No":Mobile.text]
        
    self.ref.child("regist").childByAutoId().setValue(dic)
        
    }
    
}
