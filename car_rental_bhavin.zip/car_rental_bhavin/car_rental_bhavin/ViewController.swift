//
//  ViewController.swift
//  car_rental_bhavin
//
//  Created by MAC2 on 28/02/19.
//  Copyright © 2019 MAC2. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


    @IBAction func searchbut(_ sender: UIButton) {
        
        let str = self.storyboard?.instantiateViewController(withIdentifier: "next")
        self.navigationController?.pushViewController(str!, animated: true)
        
        
    }
}

