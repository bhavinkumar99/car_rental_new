//
//  homepage.swift
//  car_rental_bhavin
//
//  Created by MAC2 on 05/03/19.
//  Copyright © 2019 MAC2. All rights reserved.
//

import UIKit

class homepage: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    
    @IBOutlet weak var text1: UITextField!
    @IBOutlet weak var text2: UITextField!
   @IBOutlet weak var text3: UITextField!
    var menuview = UIView()
    var menuteble = UITableView()
    let menuarr = [["img":"home.png","name":"Home"],["img":"profi.png","name":"My Profile"],["img":"email.png","name":"Email"],["img":"contect.png","name":"Contect Us"],["img":"gellary.png","name":"Gellery"],["img":"share.png","name":"Shere"]];
     let cityarr = ["Mumbai","Dilhi","Aahmdabad","Varansi","Baroda","Navsari","Pune","Surat","Valsad","Boisar"];
    
    override func viewDidLoad() {
        super.viewDidLoad()
     
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        menuview = UIView(frame: self.view.bounds)
        menuview.backgroundColor = UIColor.darkGray
        menuview.alpha = 0.0
        self.view.addSubview(menuview)
        
        let tapges = UITapGestureRecognizer(target: self, action: #selector(self.tap))
        menuview.isUserInteractionEnabled = true
        menuview.addGestureRecognizer(tapges)
        menuteble = UITableView(frame: CGRect(x: -200, y: 60, width: 200, height: self.view.frame.size.height), style: .grouped)
        menuteble.tag = 99
        menuteble.delegate = self
        menuteble.dataSource = self
        menuteble.backgroundColor = UIColor.orange
        self.view.addSubview(menuteble)
        
    }
    @objc func tap(sender: UITapGestureRecognizer)  {
        menuview.alpha = 0.0
        UITableView.beginAnimations(nil, context: nil)
        UITableView.setAnimationDuration(0.5)
        menuteble.frame = CGRect(x: -200, y: 60, width: 200, height: self.view.frame.size.height)
        UITableView.commitAnimations()
    }

    @IBAction func menu(_ sender: UIButton) {
        menuview.alpha = 0.5
        UITableView.beginAnimations(nil, context: nil)
        UITableView.setAnimationDuration(0.5)
        menuteble.frame = CGRect(x: 0, y: 60, width: 200, height: self.view.frame.size.height)
        UITableView.commitAnimations()
        
    }
   @IBAction func citybut(_ sender: UIButton) {
        let table = UITableView(frame:CGRect(x: 0, y:256 , width: 375, height: 248), style: .grouped);
        table.delegate = self;
        table.dataSource = self;
        self.view.addSubview(table);
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if tableView.tag == 99 {
            return 1
        }else{
            return 1
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView.tag == 99 {
            return menuarr.count
        }
        else{
            return cityarr.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView.tag == 99 {
            tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell11")
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell11", for: indexPath)
            let dic = menuarr[indexPath.row]
            cell.imageView?.image = UIImage(named: dic["img"]!)
            cell.textLabel?.text = dic["name"]
            self.view.addSubview(cell)
            return cell
        }else{
            tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell12")
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell12", for: indexPath)
            cell.textLabel?.text = String(cityarr[indexPath.row])
            
            return cell
        }
   
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView.tag == 99 {
            if indexPath.row == 1{
                let str = self.storyboard?.instantiateViewController(withIdentifier: "prof")
                self.navigationController?.pushViewController(str!, animated: true)
                menuteble.isHidden = true
                menuview.isHidden = true
                         }
            
        }else{
        text1.text = cityarr[indexPath.row]
        tableView.isHidden = true
        
    }
    
    }
    @IBAction func searchcar(_ sender: UIButton) {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "next")
        self.navigationController?.pushViewController(stb!, animated: true)
    }
}
