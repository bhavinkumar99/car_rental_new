//
//  coscell1.swift
//  car_rental_bhavin
//
//  Created by MAC2 on 04/03/19.
//  Copyright © 2019 MAC2. All rights reserved.
//

import UIKit

class coscell1: UITableViewCell {

    @IBOutlet weak var lbl: UILabel!
    @IBOutlet weak var img: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
