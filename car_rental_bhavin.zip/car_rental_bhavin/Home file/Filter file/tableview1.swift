//
//  tableview1.swift
//  car_rental_bhavin
//
//  Created by MAC2 on 04/03/19.
//  Copyright © 2019 MAC2. All rights reserved.
//

import UIKit

class tableview1: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    
       let imgarr = [["imag":"location.png","name":"location"],["imag":"rupee.png","name":"Price"],["imag":"car-cat.png","name":"Car-category"],["imag":"car-pro.png","name":"Car-Property"]];

   
   func numberOfSections(in tableView: UITableView) -> Int
   {
    if tableView.tag == 0
    {
        return 1
    }
    else
    {
        return 1
    }
   }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if tableView.tag == 0
        {
            return imgarr.count
        }
        else
        {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let tempcell = UITableViewCell()
        
        if tableView.tag == 0
        {
        let dic = imgarr[indexPath.row]
       
        let cell = tableView.dequeueReusableCell(withIdentifier: "hello", for: indexPath) as! coscell1
        cell.img.image = UIImage(named: dic["imag"]!)
        cell.lbl.text = dic["name"]
        
        return cell
        }
        else
        {
            return tempcell
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        if tableView.tag == 0{
        return 140
        }
        else
    {
        return 50
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        let navbar = UINavigationBar(frame: CGRect(x: 0, y: 20, width: 375, height: 50))
        let navitem = UINavigationItem()
        navbar.items = [navitem]
        navitem.title = "Filter By"
        self.view.addSubview(navbar)
    }
 

}
