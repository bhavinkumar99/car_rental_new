//
//  table1.swift
//  car_rental_bhavin
//
//  Created by MAC2 on 06/03/19.
//  Copyright © 2019 MAC2. All rights reserved.
//

import Foundation
import UIKit

class table1: UITableViewController{
    
    var imgarr:[[String:Any]] = []
    
    
    override func viewDidLoad() {
        imgarr =  [["imag":"location.png","name":"location"],["imag":"rupee.png","name":"Price"],["imag":"car-cat.png","name":"Car-category"],["imag":"car-pro.png","name":"Car-Property"]];
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return imgarr.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "hello", for: indexPath)as! coscell1
        let dic = imgarr[indexPath.row]
        
        cell.img.image = UIImage(named: dic["imag"] as! String)
        cell.lbl.text = dic["name"] as! String
        
        return cell
    }
}
