//
//  select_car.swift
//  car_rental_bhavin
//
//  Created by MAC2 on 28/02/19.
//  Copyright © 2019 MAC2. All rights reserved.
//

import UIKit

class select_car: UIViewController,UITableViewDataSource,UITableViewDelegate {
 
    
    let cararray = [["car_img":"ford-ecosport.png","cname":"Ford-ecosport","car_sits":"6- sits","feul":"F to F","Oil":"Diesel","manual":"manual","prize":"₹2,200"],["car_img":"ford-endeavour.png","cname":"Ford-endeavour","car_sits":"6- sits","feul":"F to F","Oil":"Diesel","manual":"manual","prize":"₹2,500"],["car_img":"honda-city.png","cname":"Honda-city","car_sits":"5- sits","feul":"F to F","Oil":"Diesel","manual":"Auto-manual","prize":"₹3,200"],["car_img":"honda amaza.png","cname":"Honda amaza","car_sits":"6-sits","feul":"F to F","Oil":"Diesel","manual":"manual","prize":"₹2,400"],["car_img":"mahindra-scorpio.png","cname":"Mahindra-scorpio","car_sits":"8-sits","feul":"F to F","Oil":"Diesel","manual":"manual","prize":"₹2,600"],["car_img":"safari-storme.png","cname":"Safari-storme","car_sits":"7-sits","feul":"F to F","Oil":"Diesel","manual":"manual","prize":"₹3,200"]];
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        
    }
  
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1;
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cararray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)as! coscell
        let  dic = cararray[indexPath.row]
        
        cell.cname.text = dic["cname"]
        cell.csit.text = dic["car_sits"]
        cell.feul.text = dic["feul"]
        cell.oil.text = dic["Oil"]
        cell.manual.text = dic["manual"]
        cell.imgview.image = UIImage(named: dic["car_img"]!)
        cell.prizelbl.text = dic["prize"]
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    @IBAction func back(_ sender: UIButton) {
        let  str = self.storyboard?.instantiateViewController(withIdentifier: "home")
        self.navigationController?.pushViewController(str!, animated: true)
        
    }
    @IBAction func filterbut(_ sender: UIButton) {
        let  str = self.storyboard?.instantiateViewController(withIdentifier: "filter")as! tableview1
        self.navigationController?.pushViewController(str, animated: true)
    }
}

