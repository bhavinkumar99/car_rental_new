//
//  coscell.swift
//  car_rental_bhavin
//
//  Created by MAC2 on 28/02/19.
//  Copyright © 2019 MAC2. All rights reserved.
//

import UIKit

class coscell: UITableViewCell {

    @IBOutlet weak var imgview: UIImageView!
    
    @IBOutlet weak var prizelbl: UILabel!
    @IBOutlet weak var manual: UILabel!
    @IBOutlet weak var feul: UILabel!
    @IBOutlet weak var cname: UILabel!
    
    @IBOutlet weak var csit: UILabel!
    
    @IBOutlet weak var oil: UILabel!
    
    
    @IBOutlet weak var bookbut: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
